#ifndef __ENTITY_STAT_H__
#define __ENTITY_STAT_H__

class EntityStat
{
public:
	int _health;
	int _attack;

	float _runSpeed;
	float _attackSpeed;
};

#endif // !__ENTITY_STAT_H__